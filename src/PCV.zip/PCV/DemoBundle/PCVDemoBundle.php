<?php

namespace PCV\DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PCVDemoBundle extends Bundle
{
}
